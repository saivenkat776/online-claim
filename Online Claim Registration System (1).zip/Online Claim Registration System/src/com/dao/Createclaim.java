package com.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Claimbean;
import com.controller.Commonconnection;

public class Createclaim extends HttpServlet {
Connection c;
	
	ResultSet rs=null;
	PreparedStatement ps=null;
	String str=null;
	RequestDispatcher rd=null;
	Claimbean cbean=new Claimbean();
	ClaimDao obj1=new ClaimDao();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			 c=Commonconnection.getCon();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String st1=request.getParameter("reason");
		String st2=request.getParameter("location");
		String st3=request.getParameter("city");
		String st4=request.getParameter("state");
		String st5=request.getParameter("zip");
         int zi=Integer.parseInt(st5);
         System.out.println(zi);
        String st6=request.getParameter("claimtype");
        cbean.setCreason(st1);
       cbean.setAlocation(st2);
        cbean.setAcity(st3);
        cbean.setAstate(st4);
        cbean.setZip(zi);
        cbean.setCtype(st6);
        ps=c.prepareStatement(QueryMapper.INSERT_QUERY);
        //String sql="insert into claim values(claimnumber_seq.nextval,?,?,?,?,?,?,policynumber_seq.nextval)";
        ps.setString(1, cbean.getCreason());
        ps.setString(2, cbean.getAlocation());
        ps.setString(3, cbean.getAcity());
        ps.setString(4, cbean.getAstate());
        ps.setInt(5, cbean.getZip());
        ps.setString(6, cbean.getCtype());
    ps.executeUpdate();
   
    obj1.doGet(request, response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
}
