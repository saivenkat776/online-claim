package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.bean.Userbean;
import com.controller.Commonconnection;

public class Createprofiledao {
	Connection c=null;
	PreparedStatement ps=null;
	
	public void addUser(Userbean bean) throws Exception
	{
		 c=Commonconnection.getCon();
		ps=c.prepareStatement("insert into userrole values(?,?,?)");
		ps.setString(1, bean.getUserName());
        ps.setString(2, bean.getPassWord());
        ps.setString(3, bean.getPassWord());
        ps.executeUpdate();
        System.out.println("Added one user data into database ");
       
	}
}
